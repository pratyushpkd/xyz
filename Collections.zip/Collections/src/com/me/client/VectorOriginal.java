package com.me.client;

import java.util.Enumeration;
import java.util.Vector;

public class VectorOriginal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer>numbers = new Vector<Integer>(3,4);
		
		numbers.addElement(10);
		numbers.addElement(20);
		numbers.addElement(30);
		numbers.addElement(40);
		
		Enumeration<Integer>enNumbers = numbers.elements();
		
		while(enNumbers.hasMoreElements()){
			System.out.println(enNumbers.nextElement());
		}
		
		numbers.insertElementAt(50, 1);//inserted element at position 1
		
		enNumbers = numbers.elements();
		System.out.println("Printing after inserting element:");
		while(enNumbers.hasMoreElements()){
			System.out.println(enNumbers.nextElement());
		}
	}
}