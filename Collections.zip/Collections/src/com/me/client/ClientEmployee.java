package com.me.client;
import java.util.ArrayList;
import java.util.List;

import com.me.entity.Employee;

public class ClientEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee>employees = new ArrayList<Employee>();
		
		Employee employee = new Employee(1,"abc",90000);
		Employee employee1 = new Employee(2,"xyz",100000);
		
		employees.add(employee);
		employees.add(employee1);
		
		for(Employee empl : employees){
			System.out.println(empl);
		}
	}
}