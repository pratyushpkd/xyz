package com.me.client;

import java.util.HashSet;
import java.util.Set;

import com.me.entity.Employee;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Employee>employees = new HashSet<Employee>();
		
		Employee employee = new Employee(1,"abc",100000);
		Employee employee1 = new Employee(2,"xyz",100000);
		Employee employee2 = new Employee(1,"abc",100000);
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		for(Employee empl : employees){
			System.out.println(empl);
		}
	}
}