package com.me.client;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class HashSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Integer>naturalNumbers = new TreeSet<Integer>();
		
		System.out.println(naturalNumbers.add(10));
		System.out.println(naturalNumbers.add(20));
		System.out.println(naturalNumbers.add(30));
		System.out.println(naturalNumbers.add(10));
		System.out.println(naturalNumbers.add(88));
		System.out.println(naturalNumbers.add(56));
		System.out.println(naturalNumbers.add(77));
		
		System.out.println(naturalNumbers);
		
		Iterator<Integer>itr = naturalNumbers.iterator();
		
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}