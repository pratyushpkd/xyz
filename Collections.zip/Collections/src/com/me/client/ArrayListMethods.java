package com.me.client;

import java.util.ArrayList;

public class ArrayListMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>numbers = new ArrayList<Integer>();
				
		numbers.add(99);
		numbers.add(100);//
		numbers.add(200);
		numbers.add(100);
		
		System.out.println("Contents of numbers:");
		System.out.println(numbers);
		
		numbers.remove(3);
		
		System.out.println("Contents of numbers after removal:");
		System.out.println(numbers);
		
		numbers.add(1, 500);//inserting at index 1.
		
		System.out.println("Contents of numbers after adding:");
		System.out.println(numbers);
	}
}