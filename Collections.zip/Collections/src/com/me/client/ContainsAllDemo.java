package com.me.client;
import java.util.ArrayList;

public class ContainsAllDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>numbers = new ArrayList<Integer>();
		ArrayList<Integer>nums = new ArrayList<Integer>();
		
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		numbers.add(10);
		
		nums.add(10);
		nums.add(20);
		nums.add(30);
		nums.add(10);
		
		if(nums.containsAll(numbers)){
			System.out.println("They are same.");
		}else{
			System.out.println("Not same.");
		}
	}
}