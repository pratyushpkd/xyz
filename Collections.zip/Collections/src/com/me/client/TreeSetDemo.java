package com.me.client;

import java.util.TreeSet;

import com.me.entity.AscEmpid;
import com.me.entity.DscEmpid;
import com.me.entity.Employee;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Employee>employees = new TreeSet<Employee>();
		
		Employee employee = new Employee(1,"abc",90000);
		Employee employee1 = new Employee(2,"xyz",100000);
		Employee employee2 = new Employee(3,"abc",85000);
		
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		System.out.println("Descending order of salary:");
		for(Employee empl : employees){
			System.out.println(empl);
		}
		
		//Ascending order of Names
		employees = new TreeSet<Employee>(new AscEmpid());
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		System.out.println("\n\nAscending order of empid:");
		for(Employee empl : employees){
			System.out.println(empl);
		}
		
		
		//Descending order of Names
		employees = new TreeSet<Employee>(new DscEmpid());
		employees.add(employee);
		employees.add(employee1);
		employees.add(employee2);
		
		System.out.println("\n\nDescending order of empid:");
		for(Employee empl : employees){
			System.out.println(empl);
		}	
	}
}