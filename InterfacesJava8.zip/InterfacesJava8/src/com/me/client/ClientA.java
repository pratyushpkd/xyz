package com.me.client;

import com.me.entity.A;
import com.me.entity.IntA;

public class ClientA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a = new A();
		a.methodA();
		
		IntA.statMethod();
	}
}