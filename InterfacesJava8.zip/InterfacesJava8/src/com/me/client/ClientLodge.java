package com.me.client;

import com.me.entity.Lodge;

public class ClientLodge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lodge lodge = new Lodge(5, "ac");
		lodge.calculateRoomBill();
		
		System.out.println(lodge);
	}
}