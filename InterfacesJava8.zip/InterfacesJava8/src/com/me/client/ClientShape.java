package com.me.client;

import com.me.entity.Circle;
import com.me.entity.IShape;
import com.me.entity.Rectangle;

public class ClientShape {

	public static void main(String[] args) {
		IShape shape = new Rectangle(10,10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);
		
		shape = new Circle(10);
		shape.calcArea();
		shape.calcPerimeter();
		System.out.println(shape);
	}
}