package com.me.entity;

public interface IShape {
	void calcArea();
	void calcPerimeter();
}