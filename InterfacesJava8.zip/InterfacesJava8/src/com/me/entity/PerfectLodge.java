package com.me.entity;

public class PerfectLodge implements IPerfectLodge {

	@Override
	public void calcTaxiBill() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calculateRoomBill() {
		// TODO Auto-generated method stub

	}

}
