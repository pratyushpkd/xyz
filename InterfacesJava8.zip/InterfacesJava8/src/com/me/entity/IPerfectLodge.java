package com.me.entity;

public interface IPerfectLodge extends IVehicleService, RoomOccupier {

}
