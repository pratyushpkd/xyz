package com.me.entity;

public class D implements IntA, IntB {

	@Override
	public void methodB() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodC() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodA() {
		// TODO Auto-generated method stub

	}

}
