package com.me.entity;

public interface RoomOccupier {
	void calculateRoomBill();
}