package com.me.entity;

public class A implements IntA {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub
		System.out.println("Inside methodA()");
	}

}
