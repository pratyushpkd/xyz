package com.me.entity;

public class B implements IntB {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub
		System.out.println("Inside method B");
	}

	@Override
	public void methodC() {
		// TODO Auto-generated method stub

	}

}
