package com.me.entity;

public interface IntA {
	void methodA();
	void methodB();
	void methodC();
	void methodD();
	void methodE();
	void methodF();
	void methodG();
	void methodH();
	void methodI();
	void methodJ();
}