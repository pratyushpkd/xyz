package com.me.entity;

public class IntBImpl implements IntB {

	@Override
	public void methodA() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodB() {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodC() {
		System.out.println("In methodC()");
	}

}
