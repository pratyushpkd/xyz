package com.me.entity;

public class MotorCycle implements IVehicle {

	@Override
	public void accelerate() {
		System.out.println("Accelerating by means of Hand accelerator");
	}

	@Override
	public void applyBrakes() {
		System.out.println("Applying brakes using leg & hand brakes");	
	}
}