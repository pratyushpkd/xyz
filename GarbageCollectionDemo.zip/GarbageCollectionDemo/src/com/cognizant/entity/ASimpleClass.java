package com.cognizant.entity;

public class ASimpleClass {
	private int number = 10;
	
	public void doSomething(){
		
	}
}
