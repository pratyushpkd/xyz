package com.cognizant.client;

import com.cognizant.entity.ASimpleClass;

public class ClientSimpleClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ASimpleClass asc = new ASimpleClass();
		
		asc.doSomething();
	}
}