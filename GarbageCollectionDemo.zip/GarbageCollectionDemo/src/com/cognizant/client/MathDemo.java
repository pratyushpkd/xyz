package com.cognizant.client;

public class MathDemo {

	public static void main(String[] args) {
		double radius = 10.25;
		double area = Math.PI * Math.pow(radius, 2);
		
		System.out.println("Area of circle is: " + area);
		int number = Math.min(10, 20);
		System.out.println("Minimum is: " + number);
		
		number = Math.max(10, 20);
		System.out.println("Maximum is: " + number);
		
		number = (int)Math.sqrt(100);
		System.out.println("Square root of 100 is: " + number);
		
		number = Math.abs(-10);
		System.out.println("Absolute of -10 is: " + number);
		
		double num = Math.round(10.45);
		System.out.println("Round of 10.45 is: " + num);
		
		num = Math.random() * 10;
		System.out.println("Random number: " + number);
		
		num = Math.random() * 10;
		System.out.println("Random number: " + number);
	}
}