package com.cognizant.client;

import java.io.IOException;
import java.util.Date;

public class GC {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Runtime rt = Runtime.getRuntime();
		System.out.println("Total JVM memory: " + rt.totalMemory());
		System.out.println("Before Memory = " + rt.freeMemory());
		Date d = null;
		for(int i = 1;i<100000;i++) {
			d = new Date();
			d = null;
		}//100000 objects eligible for garbage collection.
		
		System.out.println("After Memory = " + rt.freeMemory());
		rt.gc(); // Request for garbage collection. an alternate to System.gc()
		System.out.println("After GC Memory = " + rt.freeMemory());
		
		rt.exec("c:\\Windows\\system32\\notepad.exe");
	}
}