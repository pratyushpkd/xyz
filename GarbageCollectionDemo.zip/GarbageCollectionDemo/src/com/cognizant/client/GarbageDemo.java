package com.cognizant.client;

public class GarbageDemo {

	public static void main(String[] args) {
		String str = new String("abc");
		
		String str1 = str;
		
		str1 = new String("xyz");
		str = null;
	}
}