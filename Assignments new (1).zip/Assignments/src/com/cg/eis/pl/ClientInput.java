package com.cg.eis.pl;

import com.cg.eis.service.Service;

public class ClientInput {

	public static void main(String[] args) {
		
		//Employee employee = new Employee();	
		Service service = new Service();
		service.details();
	}

}
