package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class Service {
	
	private long id;
	private String name;
	private double salary;
	private Employee employee;

	public void details() {
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("Enter id : ");
		id = scInput.nextInt();
		scInput.nextLine();
		
		
		
		System.out.println("Enter name : ");
		name = scInput.nextLine();
		
		
		System.out.println("Enter salary : ");
		salary = scInput.nextDouble();
	
		
		//employee = new Employee(id,name,salary);
		if(salary > 5000 && salary < 20000){
			employee = new Employee(InsuranceScheme.Scheme_C,DesignationEmployee.System_Associate);
		}
		else if(salary >= 20000 && salary < 40000){
			employee = new Employee(InsuranceScheme.Scheme_B,DesignationEmployee.Programmer);
		}
		else if(salary >= 40000){
			employee = new Employee(InsuranceScheme.Scheme_A,DesignationEmployee.Manager);
		}
		else if(salary <= 5000){
			employee = new Employee(InsuranceScheme.No_Scheme,DesignationEmployee.Clerk);
		}
		
		employee.setId(id);
		employee.setName(name);
		employee.setSalary(salary);
		
		System.out.println(employee);
		scInput.close();
	}
}
