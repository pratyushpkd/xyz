package com.cg.eis.bean;

import com.cg.eis.service.DesignationEmployee;
import com.cg.eis.service.InsuranceScheme;

public class Employee {
	private long id;
	private String name;
	private double salary;
	private DesignationEmployee designation;
	private InsuranceScheme insuranceScheme;
	
	public Employee(long id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public Employee() {

	}
	
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public Employee(InsuranceScheme insuranceScheme,
			DesignationEmployee designation) {
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}


	@Override
	public String toString() {
		return "\n\nEmployee Details\n\nId = " + id + "\nName = " + name + "\nSalary = " + salary
				+ "\nDesignation = " + designation + "\nInsurance Scheme = "
				+ insuranceScheme;
	}
	
}
