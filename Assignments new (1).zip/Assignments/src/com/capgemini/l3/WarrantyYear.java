package com.capgemini.l3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class WarrantyYear {

	public static void output(String inpDate, int dys){
		
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			cal.setTime(sdf.parse(inpDate));
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
		
		cal.add(Calendar.DAY_OF_MONTH, dys);  
	
		String warrantyDate = sdf.format(cal.getTime());  

		System.out.println("Warranty ends on date: "+ warrantyDate);
		
	}
	
	public static void main(String[] args) {
			
		Scanner scanf = new Scanner(System.in);
		String dt;
		int period;
		
		System.out.print("Enter the purchase date in dd/MM/yyyy format: ");
		dt = scanf.next();
		
		System.out.print("Enter warranty period: ");
		period = scanf.nextInt();
		scanf.close();
 		
		output(dt,period);

	}


}
