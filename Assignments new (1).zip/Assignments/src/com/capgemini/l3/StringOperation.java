package com.capgemini.l3;

import java.util.Scanner;

public class StringOperation {

	public static void main(String[] args) {
		
		String str;
		char choice;
		char a;
		Scanner scanf = new Scanner(System.in);
		
		System.out.println("Operations");
		System.out.println("1. Add the String to itself");
		System.out.println("2. Replace odd positions with #");
		System.out.println("3. Remove duplicate characters in the String");
		System.out.println("4. Change odd characters to upper case\n");

		System.out.println("Enter the String: ");
		str = scanf.nextLine();
		
		System.out.println("Select the operation: ");
		choice = scanf.next().charAt(0);
		int length=str.length();
		switch(choice)
		{
			case '1':
				System.out.print("\nAdded the String to itself: \n");
						str = str.concat(str);
						System.out.println(str);
						break;
			case '2':
						System.out.print("\nReplaced odd positions with #: \n");
						for(int i = 0; i < length; i++)
						{
							if(i%2==0)
							{
								System.out.print("#");
							}
							else
							{
								System.out.print(Character.toString(str.charAt(i)));
							}
							
						}
						break;
				
			case '3':
						String ans="";
						System.out.print("Removed duplicate characters from the String: \n");
						for(int i = 0; i < length; i++)
						{
							a = str.charAt(i);
							if(a!=' ')
							{
								ans = ans + a;
							}
								str = str.replace(a,' ');
						}
						System.out.println(ans);
						break;
				
			case '4':
				
						System.out.print("Changed odd characters to upper case: \n");
						for(int i = 0; i < length; i++)
						{
							a = str.charAt(i);
							if(i%2==0)
							{
								
								if(a>=97 && a<=122)
								{
									a=Character.toUpperCase(a);
								}
								
								System.out.print(a);
								
							}
							else
							{
								System.out.print(a);
							}
					
						}
						break;
			default:
						System.out.println("Please select an appropriate option number");
						break;
		}
		
		scanf.close();
		
		}

}
