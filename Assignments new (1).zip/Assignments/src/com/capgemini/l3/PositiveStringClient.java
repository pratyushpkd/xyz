package com.capgemini.l3;

import java.util.Scanner;

public class PositiveStringClient {
	
	public static void main(String[] args) {
		
		PositiveString pstring;
		Scanner scanf = new Scanner(System.in);
		String str;
		
		System.out.println("Enter a string: ");
		str = scanf.nextLine();
		scanf.close();
		pstring = new PositiveString(str);
		
		boolean pn=PositiveString.check();
		
		if(pn)
		{
			System.out.println("Positive String");
		}
		else
		{
			System.out.println("Negative String");
		}

	}

}
