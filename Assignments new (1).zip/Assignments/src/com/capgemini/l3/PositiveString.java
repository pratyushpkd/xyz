package com.capgemini.l3;

public class PositiveString {

	static String str;
	public PositiveString(String str) {
		PositiveString.str = str;
	}
		
	public static boolean check(){
		
	
		char a,b;
		int flag=0;
		
		int length = str.length();
		
		for(int i = 0 ; i < length-1; i++)
		{
			a=str.charAt(i);
			b=str.charAt(i+1);
			
			if(a>b)
			{
				flag=1;
				break;
			}
		
		}
		if(flag==0)
		{
			return true;
		}
		else
		{
			return false;
		}

	}

}
