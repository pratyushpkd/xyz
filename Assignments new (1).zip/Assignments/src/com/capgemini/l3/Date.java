package com.capgemini.l3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.Scanner;

public class Date {
	
	public static void output(LocalDate inpDate) {
		long diffDays = ChronoUnit.DAYS.between(inpDate, LocalDate.now());
		System.out.println("Duration in days: " + diffDays);
		
		long diffMonths = ChronoUnit.MONTHS.between(inpDate, LocalDate.now());
		System.out.println("Duration in months: " + diffMonths);
		
		long diffYears = ChronoUnit.YEARS.between(inpDate, LocalDate.now());
		System.out.println("Duration in years: " + diffYears);
	}
	
	public static void main(String[] args) {
		
		Scanner scanf = new Scanner(System.in);
		String dt1;
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		System.out.print("Enter date in dd/MM/yyyy format: ");
		dt1 = scanf.next();
		scanf.close();
		
		TemporalAccessor ta =  dtf.parse(dt1);
		LocalDate ld = LocalDate.from(ta);
		// LocalDate today = LocalDate.now();
		//System.out.println(ld);
		
		output(ld);
		
	}
}
