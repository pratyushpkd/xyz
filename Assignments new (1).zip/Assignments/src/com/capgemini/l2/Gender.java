package com.capgemini.l2;

public enum Gender {
	M,F
}
