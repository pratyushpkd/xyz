package com.capgemini.l2;

public class print {

	public static void main(String[] args) {
		System.out.println("Person Details:");
		System.out.println("_______________");
		System.out.println();
		System.out.println("First name: Divya");
		System.out.println("Last name: Bharathi");
		System.out.println("Gender: F");
		System.out.println("Age: 20");
		System.out.println("Weight: 85.55");
	}

}
