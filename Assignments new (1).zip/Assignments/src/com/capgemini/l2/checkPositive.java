package com.capgemini.l2;

import java.util.Scanner;

public class checkPositive {

	public static void main(String[] args) {
		Scanner scanf = new Scanner(System.in);
		int number;
		System.out.println("Enter a number: ");
		number = Integer.parseInt(scanf.nextLine());
		
		if( number >= 0)
		{
			System.out.println("Number is positive");
		}
		else
		{
			System.out.println("Number is negative");
		}
		scanf.close();
	}

}
