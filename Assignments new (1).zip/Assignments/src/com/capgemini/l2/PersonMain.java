package com.capgemini.l2;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		person Person;
		String fname="Divya";
		String lname="Bharathi";
		Gender gender;
		
		System.out.println("Enter the phone number: ");
		Scanner scanf = new Scanner(System.in);
		
		gender = Gender.F;
		
		String phone = scanf.nextLine();
		Person = new person(fname,lname,gender,phone);
		
		System.out.println(Person);
		
		scanf.close();
	}
	
}