package com.capgemini.l4;

public class CurrentAccount extends Account {

	private static final double overdraft = -1000;
	private double balance;
	
	public CurrentAccount(double balance, Person accholder) {
		super(balance, accholder);
		this.balance = balance;
	}
	
	@Override
	public void withdraw(double amount) {
		
		if((balance - amount) < overdraft)
		{
			System.out.println("Attention Withdrawal cancelled of amount : " + amount + "!! You have crossed the overdraft limit of " + overdraft);
		}
		else
		{
			System.out.println("Withdrawal Succesfull!!! Withdrawal amount : " + amount);
			balance = balance - amount;
		}
		System.out.println(toString());
	}
	
	@Override
	public String toString() {
		return "Account Summary\nAccount Number : " + accNum + accholder + "\nBalance : " + balance + "\n\n";
	}
	
}
