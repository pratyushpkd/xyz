package com.capgemini.l4;

import java.util.Scanner;

public class AccountClient {
	
	public static void main(String[] args) {
		
		Scanner scInput = new Scanner(System.in);
		
		//4.1 Assignment==============================================================================
		Person person1 = new Person("Smith",25);
		Person person2 = new Person("Kathy",30);
		
		Account account1 = new Account(2000,person1);
		Account account2 = new Account(3000,person2);
		
		account1.deposit(2000);
		System.out.println(account1);
		
		account2.withdraw(2000);
		System.out.println(account2);
		//END=========================================================================================
		
		//4.2 Assignment==============================================================================
		
		person1 = new Person("Raj",22);
		person2 = new Person("Suresh",31);
		
		
		CurrentAccount ca1 = new CurrentAccount(2000,person1);
		ca1.withdraw(3500);
		
		SavingsAccount ca2 = new SavingsAccount(3000,person2);
		ca2.withdraw(500);
		
		//END=========================================================================================
		
		scInput.close();
	}

}
