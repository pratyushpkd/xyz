package com.capgemini.l6;

public class Account {
	private static long acNo = 1924564; // Selected a random starting Account Number
	
	protected long accNum;
	protected static final double minbalance = 500;
	protected double balance;
	protected Person accholder;
	
	
	public Account(double balance, Person accholder) {
		this.accNum = ++acNo;
		this.balance = balance;
		this.accholder = accholder;
	}

	
	//FUNCTIONS=============================================================
	
	public void deposit(double amount){
		System.out.println("Deposited!! amount : " + amount);
		balance = balance + amount;
	}
	
	public void withdraw(double amount) {
		
		System.out.println("Withdrawal Succeeded!! of amount : " + amount);
		if((balance - amount) < minbalance)
		{
			System.out.println("Attention!! You need to maintain the minimum balance of " + minbalance + " in your account");
		}
		else
		{
			balance = balance - amount;
			
		}
	}
	
	//=================================================================
	
	
	public long getAccNum() {
		return accNum;
	}


	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	public Person getAccholder() {
		return accholder;
	}


	public void setAccholder(Person accholder) {
		this.accholder = accholder;
	}
	
	public String details() {
		return "Account Summary hello\nAccount Number : " + accNum + accholder + "\n\n";
	}

	@Override
	public String toString() {
		return "Account Summary\nAccount Number : " + accNum + accholder + "\nBalance : " + balance + "\n\n";
	}
	
	
	
}
