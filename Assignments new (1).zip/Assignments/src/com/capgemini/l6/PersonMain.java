package com.capgemini.l6;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Person2 Person;
		String fname = null;
		String lname = null;
		Gender gender;
		
		Scanner scanf = new Scanner(System.in);
		
		System.out.println("Enter the First Name: ");
		try {
				fname = scanf.nextLine();
				if(fname.length()==0) {
					scanf.close();
					throw new Exception();
					
				}
		} catch(Exception e) {
			System.err.println("Error: First name should not be empty\n");
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Enter the Last Name: ");
		try {
			lname = scanf.nextLine();
			if(lname.length()==0) {
				scanf.close();
				throw new Exception();
			}
		} catch(Exception e) {
			System.err.println("Error: Last name should not be empty\n");
			e.printStackTrace();
			System.exit(1);
		}
		
		System.out.println("Enter the phone number: ");
		String phone = scanf.nextLine();
		
		gender = Gender.F;
		
		Person = new Person2(fname,lname,gender,phone);
		
		System.out.println(Person);
		
		scanf.close();
	}
	
}