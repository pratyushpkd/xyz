package com.capgemini.l6;

public enum Gender {
	M,F
}
