package com.capgemini.l6;

public class SavingsAccount extends Account {

	private static final double minimumBalance = 1000;
	private double balance;
	
	public SavingsAccount(double balance, Person accholder) {
		super(balance, accholder);
		this.balance=balance;
	}
	
	@Override
	public void withdraw(double amount) {
		if((balance - amount) < minimumBalance)
		{
			System.out.println("Attention Withdrawal Cancelled of amount : " + amount + "!! You need to maintain the minimum balance of " + minimumBalance + " in your account");
		}
		else
		{
			System.out.println("Withdrawal Succesfull!!! Withdrawal amount : " + amount);
			balance = balance - amount;
		}
		System.out.println(toString());
	}
	@Override
	public String toString() {
		return "Account Summary\nAccount Number : " + accNum + accholder + "\nBalance : " + balance + "\n\n";
	}
}
