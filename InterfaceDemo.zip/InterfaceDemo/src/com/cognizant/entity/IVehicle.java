package com.cognizant.entity;

public interface IVehicle {
	int number = 10;//public static final by default
	void accelerate();//public abstract by default.
	void applyBrakes();
}