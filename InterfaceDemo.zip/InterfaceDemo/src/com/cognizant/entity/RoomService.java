package com.cognizant.entity;

public interface RoomService {
	void calcRoom();
}