package com.cognizant.entity;

public interface VehicleService {
	void calcBill();
}