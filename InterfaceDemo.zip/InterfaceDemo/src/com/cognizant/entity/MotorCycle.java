package com.cognizant.entity;

public class MotorCycle implements IVehicle {

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("Accelerating by hand accelerator.");
	}

	@Override
	public void applyBrakes() {
		// TODO Auto-generated method stub
		System.out.println("Applying brakes by hand and foot.");
	}

}
