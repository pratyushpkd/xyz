package com.cognizant.entity;

public class Circle implements IShape {
	private float radius;
	private float area;
	private float peri;
	
	public Circle(float radius) {
		super();
		this.radius = radius;
	}

	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		area = PI * radius * radius;
	}

	@Override
	public void calcPeri() {
		// TODO Auto-generated method stub
		peri = 2 * PI * radius;
	}

	@Override
	public String toString() {
		return "Circle [radius=" + radius + ", area=" + area + ", peri=" + peri
				+ "]";
	}
}