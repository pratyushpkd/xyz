package com.cognizant.entity;

public class Lodge1 implements Experiment {
	private static int roomCharge = 2500;
	private static float perKMRate = 18.50f;
	
	private int roomNo;
	private int daysStayed;
	private int distance;
	private float roomBill;
	private float vehicleBill;
	private float totalBill;
	
	public Lodge1(int roomNo, int daysStayed, int distance) {
		super();
		this.roomNo = roomNo;
		this.daysStayed = daysStayed;
		this.distance = distance;
	}

	@Override
	public void calcBill() {
		// TODO Auto-generated method stub
		vehicleBill = this.distance * perKMRate;
	}

	
	@Override
	public String toString() {
		return "Lodge1 [roomNo=" + roomNo + ", daysStayed=" + daysStayed
				+ ", distance=" + distance + ", roomBill=" + roomBill
				+ ", vehicleBill=" + vehicleBill + ", totalBill=" + totalBill
				+ "]";
	}

	@Override
	public void calcRoom() {
		// TODO Auto-generated method stub
		roomBill = this.daysStayed * roomCharge;
		calcBill();
		this.totalBill = roomBill + vehicleBill;
	}	
}