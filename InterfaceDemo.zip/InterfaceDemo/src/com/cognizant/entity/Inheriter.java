package com.cognizant.entity;

public class Inheriter extends ToBeInherited {
	@Override
	public void message(){
		System.out.println("Another simple message");
	}
}
