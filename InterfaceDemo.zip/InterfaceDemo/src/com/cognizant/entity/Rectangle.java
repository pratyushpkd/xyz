package com.cognizant.entity;

public class Rectangle implements IShape {
	private float l;
	private float b;
	private float area;
	private float peri;
	
	
	public Rectangle(float l, float b) {
		super();
		this.l = l;
		this.b = b;
	}

	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		area = l * b;
	}

	@Override
	public void calcPeri() {
		// TODO Auto-generated method stub
		peri = 2 * (l + b);
	}

	@Override
	public String toString() {
		return "Rectangle [l=" + l + ", b=" + b + ", area=" + area + ", peri="
				+ peri + "]";
	}
	
	
}