package com.cognizant.entity;

public interface Rooms {
	void calcRooms();
}