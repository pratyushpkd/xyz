package com.cognizant.entity;

public class Bicycle implements IVehicle {

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("Accelerating by foot pedals.");
	}

	@Override
	public void applyBrakes() {
		// TODO Auto-generated method stub
		System.out.println("Applying hand brakes.");
	}

}
