package com.cognizant.entity;

public class ToBeInherited {
	public void message(){
		System.out.println("Simple Message");
	}
}
