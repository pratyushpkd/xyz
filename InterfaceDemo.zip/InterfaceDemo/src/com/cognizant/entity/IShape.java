package com.cognizant.entity;

public interface IShape {
	//No instance variables are allowed.
	float PI = 3.14f;//public static final
	void calcArea();//public abstract
	void calcPeri();//public abstract
}