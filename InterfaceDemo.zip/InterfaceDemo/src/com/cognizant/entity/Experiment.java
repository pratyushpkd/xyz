package com.cognizant.entity;

public interface Experiment extends RoomService, VehicleService{
	
}