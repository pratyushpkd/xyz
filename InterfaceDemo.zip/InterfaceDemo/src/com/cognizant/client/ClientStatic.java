package com.cognizant.client;

import com.cognizant.entity.Adder;

public class ClientStatic {

	public static void main(String[] args) {
		Adder add = new Adder();
		
		System.out.println(add.add(10, 20));
		System.out.println(add.add(10.90f, 20.78f));
	}
}