package com.cognizant.client;
import static java.lang.System.out;

import com.cognizant.entity.Circle;
import com.cognizant.entity.IShape;
import com.cognizant.entity.Rectangle;

public class ClientShape {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Circle circle = new Circle(10);
		Rectangle rectangle = new Rectangle(10, 10);
		
		IShape shapes[] = {circle,rectangle};
		
		for (int i = 0; i < shapes.length; i++) {
			shapes[i].calcArea();
			shapes[i].calcPeri();
			System.out.println(shapes[i]);
		}
/*		shape.calcArea();
		shape.calcPeri();
		out.println(shape);
		
		shape = 
		shape.calcArea();
		shape.calcPeri();
		out.println(shape);*/
	}
}