package com.cognizant.client;

import com.cognizant.entity.Experiment;
import com.cognizant.entity.Inheriter;
import com.cognizant.entity.ToBeInherited;

public class ClientInherit {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ToBeInherited e = new Inheriter();
		
		e.message();
	}
}