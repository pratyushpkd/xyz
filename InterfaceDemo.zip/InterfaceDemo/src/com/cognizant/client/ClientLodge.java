package com.cognizant.client;

import com.cognizant.entity.Lodge1;

public class ClientLodge {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lodge1 lodge = new Lodge1(1, 5, 20);
		lodge.calcRoom();
		
		System.out.println(lodge);
	}

}
