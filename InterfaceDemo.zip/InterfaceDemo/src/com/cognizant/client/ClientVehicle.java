package com.cognizant.client;

import com.cognizant.entity.Bicycle;
import com.cognizant.entity.MotorCycle;

public class ClientVehicle {

	public static void main(String[] args) {
		Bicycle bicycle = new Bicycle();
		bicycle.accelerate();
		bicycle.applyBrakes();
		
		MotorCycle mcycle = new MotorCycle();
		mcycle.accelerate();
		mcycle.applyBrakes();		
	}
}