package com.cognizant.client;
import static java.lang.System.out;

public class DemoStaticImport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = add(10,20);
		out.println("Sum: " + sum);
		
		sum = add(10,20,30);
		out.println("Sum: " + sum);
		
		sum = add(10);
		out.println("Sum: " + sum);
	}
	
	public static int add(int... var){
		int sum = 0;
		
		for(int i = 0 ; i < var.length ; i++){
			sum += var[i];
		}
		return sum;
	}
}