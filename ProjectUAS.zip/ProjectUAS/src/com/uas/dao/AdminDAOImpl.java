package com.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.CustomException;
import com.uas.util.DBConnection;

public class AdminDAOImpl implements IAdminDAO {

	@Override
	public boolean isAuthenticated(String loginId, String pass, UserRole role)
			throws CustomException {
		int records=0;
		boolean isAuthenticated = false;
		try(Connection connAdmin = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connAdmin.prepareStatement(AdminQueryMapper.IS_AUTHENTICATED);
				ResultSet rsAuthenticated = preparedStatement.executeQuery();
				){
			while(rsAuthenticated.next()){
				UserBean admin = new UserBean();
				
				admin.setLoginId(rsAuthenticated.getString("loginId"));
				admin.setPassword(rsAuthenticated.getString("password"));
				admin.setRole(UserRole.valueOf(rsAuthenticated.getString("role")));
				
				
			}
			
			if(records==0){
				throw new CustomException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		return isAuthenticated;
		
		
	}

	@Override
	public boolean deleteProgramOffered(String programName)
			throws CustomException {
		
		int records =0;
		boolean isDeleted = false;
		
		try(Connection connAdmin = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connAdmin.prepareStatement(AdminQueryMapper.DELETE_PROGRAM_OFFERED);
				){
			preparedStatement.setString(1, programName);
			
			records = preparedStatement.executeUpdate();
			
			if(records >0){
				isDeleted= true;
			}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		return isDeleted;	
	}

	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws CustomException {
		int records = 0;
		boolean isInserted = false;
		
		try(Connection connAdmin =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connAdmin.prepareStatement(AdminQueryMapper.ADD_PROGRAM_OFFERED);
				){
				
				preparedStatement.setString(1, programsOfferedBean.getProgramName());
				preparedStatement.setString(2, programsOfferedBean.getDescription());
				preparedStatement.setString(3, programsOfferedBean.getApplicantEligibility());
				preparedStatement.setByte(4, programsOfferedBean.getDuration());
				preparedStatement.setString(5, programsOfferedBean.getDegreeOffered());
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isInserted = true;
				}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws CustomException {
		List<ProgramsScheduledBean>programScheduledList = new ArrayList<ProgramsScheduledBean>();
		
		try(Connection connAdmin = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connAdmin.prepareStatement(AdminQueryMapper.VIEW_PROGRAM_SCHEDULED);
				ResultSet rsProgramsScheduled = preparedStatement.executeQuery();
				){
			while(rsProgramsScheduled.next()){
				ProgramsScheduledBean admin = new ProgramsScheduledBean();
				
				admin.setProgramId(rsProgramsScheduled.getString("programId"));
				admin.setCity(rsProgramsScheduled.getString("city"));
				admin.setState(rsProgramsScheduled.getString("state"));
				admin.setZipCode(rsProgramsScheduled.getInt("zipcode"));
				admin.setStartDate(rsProgramsScheduled.getDate("startDate").toLocalDate());
				admin.setEndDate(rsProgramsScheduled.getDate("endDate").toLocalDate());
				admin.setSessionPerWeek(rsProgramsScheduled.getByte("sessionPerWeek"));
				
				programScheduledList.add(admin);
			}
			
			if(programScheduledList.size()==0){
				throw new CustomException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		return programScheduledList;
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws CustomException {
		
		int records =0;
		boolean isDeleted = false;
		
		try(Connection connAdmin = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connAdmin.prepareStatement(AdminQueryMapper.DELETE_PROGRAM_SCHEDULED);
				){
			preparedStatement.setString(1, programId);
			
			records = preparedStatement.executeUpdate();
			
			if(records >0){
				isDeleted= true;
			}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		return isDeleted;	
		
	}

	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws CustomException {
		int records = 0;
		boolean isInserted = false;
		
		try(Connection connAdmin =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connAdmin.prepareStatement(AdminQueryMapper.ADD_PROGRAM_SCHEDULED);
				){
				
				preparedStatement.setString(1, programsScheduledBean.getProgramId());
				preparedStatement.setString(2, programsScheduledBean.getCity());
				preparedStatement.setString(3, programsScheduledBean.getState());
				preparedStatement.setInt(4, programsScheduledBean.getZipCode());
				preparedStatement.setDate(5, Date.valueOf(programsScheduledBean.getStartDate()));
				preparedStatement.setDate(6, Date.valueOf(programsScheduledBean.getEndDate()));
				preparedStatement.setByte(7, programsScheduledBean.getSessionPerWeek());
				
				records = preparedStatement.executeUpdate();
				if(records > 0){
					isInserted = true;
				}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		
		return isInserted;
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants() throws CustomException {
		
		List<ApplicantBean>applicantList = new ArrayList<ApplicantBean>();
		
		try(Connection connAdmin = DBConnection.getInstance().getConnection();	
				PreparedStatement preparedStatement=
						connAdmin.prepareStatement(AdminQueryMapper.VIEW_APPLICANTS);
				ResultSet rsApplicants = preparedStatement.executeQuery();
				){
			while(rsApplicants.next()){
				ApplicantBean admin = new ApplicantBean();
				
				admin.setApplicationId(rsApplicants.getInt("applicationId"));
				admin.setFullName(rsApplicants.getString("fullName"));
				admin.setDateOfBirth(rsApplicants.getDate("dateOfBirth").toLocalDate());
				admin.setHighestQualification(rsApplicants.getString("highestQualification"));
				admin.setMarksObtained(rsApplicants.getInt("marksObtained"));
				admin.setGoals(rsApplicants.getString("goals"));
				admin.setEmail_id(rsApplicants.getString("email_id"));
				admin.setStatus(Application_Status.valueOf(rsApplicants.getString("status")));
				admin.setDateOfInterview(rsApplicants.getDate("dateOfInterview").toLocalDate());
				
				
				applicantList.add(admin);
			}
			
			if(applicantList.size()==0){
				throw new CustomException("No records found.");
			}
		}catch(SQLException sqlEx){
			throw new CustomException(sqlEx.getMessage());
		}
		return applicantList;
	}

}
