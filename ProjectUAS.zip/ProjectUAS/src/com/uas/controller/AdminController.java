package com.uas.controller;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.util.Scanner;

import com.uas.bean.ProgramsOfferedBean;
import com.uas.exception.CustomException;
import com.uas.service.AdminService;

public class AdminController 
{
	private static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) 
	{
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		boolean isInProcess=true;
		
		
		byte choice=0;
		
		String programName=null; //primary key
		String description=null;
		String applicantEligibility=null;
		byte duration=0;
		String degreeOffered=null;
		
		Scanner sc=new Scanner(System.in);
		
		AdminService serviceAdmin=new AdminService();
		
		ProgramsOfferedBean programsOfferedBean=null;
		
		while(isInProcess)
		{
			System.out.println("1) Insert Programs Offered");
			System.out.println("2) Delete Programs Offered");
			System.out.println("0) Exit");
			
         choice=Byte.parseByte(sc.nextLine());
			
			switch(choice){
			case 1:
		
				System.out.println("Enter program name: ");
				programName=sc.nextLine();
				System.out.println("Enter description: ");
				description=sc.nextLine();
				System.out.println("Enter applicant eligibility: ");
				applicantEligibility=sc.nextLine();
				System.out.println("Enter duration: ");
				duration=Byte.parseByte(sc.nextLine());
				System.out.println("Enter degree offered: ");
				degreeOffered=sc.nextLine();
				
				
				programsOfferedBean=new ProgramsOfferedBean(programName,description,applicantEligibility,duration,degreeOffered);
				try{
					boolean isInserted=serviceAdmin.addProgramOffered(programsOfferedBean);
					
					if(isInserted)
						System.out.println("Inserted Successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 2:
				System.out.println("Enter program name: ");
				String programNam=sc.nextLine();
				
				try{
					boolean isDeleted=serviceAdmin.deleteProgramOffered(programNam);
					
					if(isDeleted)
						System.out.println("Deleted successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
		
           case 0:
				
				isInProcess=false;
				break;
				
			default:
				
				System.out.println("Invalid input");
				logger.error("Invalid input: "+choice);
				System.err.println("Invalid input: "+choice);
				break;
	}
}
		sc.close();
}
}