package com.uas.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.CustomException;
import com.uas.service.AdminService;

public class AdminControllerPS 
{
	private static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) 
	{
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		boolean isInProcess=true;
		
		
		byte choice=0;
		
		String programId=null;
		String city=null;
		String state=null;
		int zipCode=0;
		
		byte sessionPerWeek=0;
		List<ProgramsScheduledBean>programsScheduledList = null;
		Scanner sc=new Scanner(System.in);
		
		AdminService serviceAdmin=new AdminService();
		
		ProgramsScheduledBean programsScheduledBean=null;
		
		while(isInProcess)
		{
			System.out.println("1) Insert Programs Scheduled");
			System.out.println("2) Delete Programs Scheduled");
			System.out.println("3) Select Programs Scheduled");
			System.out.println("0) Exit");
			
         choice=Byte.parseByte(sc.nextLine());
			
			switch(choice){
			case 1:
		
				System.out.println("Enter program id: ");
				programId=sc.nextLine();
				System.out.println("Enter city: ");
				city=sc.nextLine();
				System.out.println("Enter state: ");
				state=sc.nextLine();
				System.out.println("Enter zipcode: ");
				zipCode=Integer.parseInt(sc.nextLine());
				
				System.out.println("Enter start date: ");
				String date1 = sc.nextLine();
				DateTimeFormatter germanFormatter = DateTimeFormatter.ofLocalizedDate(
					        FormatStyle.MEDIUM).withLocale(Locale.GERMAN);

				LocalDate startDate = LocalDate.parse(date1, germanFormatter);
				
				System.out.println("Enter end date: ");
				String date2 = sc.nextLine();
				

				LocalDate endDate = LocalDate.parse(date2, germanFormatter);
					    
				System.out.println("Enter sessions per week: ");
				sessionPerWeek=Byte.parseByte(sc.nextLine());
				
				
				programsScheduledBean=new ProgramsScheduledBean(programId,city,state,zipCode,startDate, endDate, sessionPerWeek);
				try{
					boolean isInserted=serviceAdmin.addProgramScheduled(programsScheduledBean);
					
					if(isInserted)
						System.out.println("Inserted Successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 2:
				System.out.println("Enter program id: ");
				String progId=sc.nextLine();
				
				try{
					boolean isDeleted=serviceAdmin.deleteProgramScheduled(progId);
					
					if(isDeleted)
						System.out.println("Deleted successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 3:
				try{
					programsScheduledList = serviceAdmin.viewProgramsScheduled();
						for (ProgramsScheduledBean mobileBean : programsScheduledList){
							System.out.println(mobileBean);
						}
						System.out.println("====================================================================");
					}catch(CustomException e){
						logger.error(e.getMessage());
					}
					break;
		
           case 0:
				
				isInProcess=false;
				break;
				
			default:
				
				System.out.println("Invalid input");
				logger.error("Invalid input: "+choice);
				System.err.println("Invalid input: "+choice);
				break;
	}
}
		sc.close();
}
}
