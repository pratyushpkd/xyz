package com.bvk.client;

import java.util.Scanner;

import com.bvk.dao.EmployeeDAO;
import com.bvk.dao.EmployeeDAOImpl;
import com.bvk.entity.EmployeeTO;

public class ClientCallableProcedureIn {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int empid = 0;
		String name = null;
		float salary = 0.0f;

		EmployeeTO employeeTO = null;
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		
		System.out.print("Enter Employee ID: ");
		empid = sc.nextInt();
				sc.nextLine();
				 
		System.out.print("Enter Employee Name: ");
		name = sc.nextLine();

		System.out.print("Enter Employee Salary: ");
		salary = sc.nextFloat(); 
				 sc.nextLine();

		employeeTO = new EmployeeTO(empid, name, salary);
		int status = employeeDAO.insertUsingProcedure(employeeTO);
		
		if(status == 1){
			System.out.println("Record inserted successfully...");
		}else{
			System.out.println("Record couldn't be inserted...");
		}
	}
}