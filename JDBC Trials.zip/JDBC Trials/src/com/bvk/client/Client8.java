package com.bvk.client;

public class Client8 {

	public static void main(String[] args) {
		Dao dao = new Dao();
		float updatedSalary = 0;
		int empid = 11;
		
		dao.updateSalary(empid, updatedSalary);
	}

}
