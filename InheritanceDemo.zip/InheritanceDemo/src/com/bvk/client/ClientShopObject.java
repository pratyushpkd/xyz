package com.bvk.client;

import com.bvk.entity.Mall;
import com.bvk.entity.Shop;

public class ClientShopObject {

	public static void main(String[] args) {
		Shop shop = new Mall(1, "abc mall", 500000, 5000, 5000);
		shop.calculate();//Mall
		shop.output();//Mall
		System.out.println("==========================================");

		Mall mall = (Mall)shop;
		mall.output();
		System.out.println("==========================================");
		
		shop = new Shop(2, "xyz general stores", 600000, 5000);
		shop.calculate();
		shop.output();
		System.out.println("==========================================");
		
		mall = (Mall)shop;
		mall.calculate();
		mall.output();
		
	}
}