package com.bvk.client;

public class Arith {
	public int add(int a, int b){
		System.out.println("Inside integer version");
		return (a+b);
	}
	
	public float add(float a, float b){
		System.out.println("Inside float version");
		return (a+b);
	}
}