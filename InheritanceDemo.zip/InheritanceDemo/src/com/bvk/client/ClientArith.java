package com.bvk.client;

public class ClientArith {

	public static void main(String[] args) {
		Arith arith = new Arith();
		
		System.out.println(arith.add(10, 10));
		System.out.println(arith.add(10.89f, 10.23f));
		System.out.println(arith.add(10, 10.89f));
	}
}