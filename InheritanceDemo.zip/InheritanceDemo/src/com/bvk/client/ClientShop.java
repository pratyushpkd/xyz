package com.bvk.client;

import com.bvk.entity.Mall;
import com.bvk.entity.Shop;

public class ClientShop {

	public static void main(String[] args) {
		Shop shop = new Shop(1, "abc", 500000, 5000);
		shop.calculate();
		//shop.output();
		System.out.println(shop);//shop.toString()
		
		Mall mall = new Mall(2, "Star Bucks", 5000000, 50000,5000);
		mall.calculate();
		//mall.output();
		System.out.println(mall);//mall.toString()
	}
}