package com.bvk.entity;

import java.util.Scanner;

public abstract class AbstractStudent {
	private int rollno;
	private String name;
	protected int total;
	protected float percent;
	
	public AbstractStudent() {
	}

	public void input(){
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter rollno: ");
		rollno = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter name: ");
		name = scInput.nextLine();		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	public int getRollno() {
		return rollno;
	}

	public abstract void calculateTotal();
	public abstract void calculatePercent();
	
	@Override
	public String toString() {
		return "AbstractStudent [rollno=" + rollno + ", name=" + name + "]";
	}
}