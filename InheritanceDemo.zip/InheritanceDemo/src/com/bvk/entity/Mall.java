package com.bvk.entity;

public class Mall extends Shop {
	//Variables from Shop are already inherited.
	
	private float exportImportTax;

	public Mall() {
		super();
	}

	public Mall(int shopId, String name, float profit, float tax, float exportImportTax) {
		//this();
		super(shopId, name, profit, tax);
		//super();//automatically done when no super class constructor called.
		this.exportImportTax = exportImportTax;
	}

	public float getExportImportTax() {
		return exportImportTax;
	}

	public void setExportImportTax(float exportImportTax) {
		this.exportImportTax = exportImportTax;
	}
	
	@Override
	public void calculate(){
/*		super.calculate();
		float pat = getProfitAfterTax();
		pat -= this.exportImportTax;
		setProfitAfterTax(pat);*/
		super.calculate();
		this.profitAfterTax = this.profitAfterTax - this.exportImportTax;
	}
	
	@Override
	public void output(){
		super.output();
		System.out.println("Export Import Tax: " + this.exportImportTax);
	}
	@Override
	public String toString(){
		String text = "Shop ID: " + getShopId() + "\n" +
				  "Shop Name: " + getName() + "\n" +
				  "Profit: " + getProfit() + "\n" +
				  "Tax: " + getTax() + "\n" +
				  "Export Import Tax: " + this.exportImportTax + "\n" +
				  "Profit After Tax: " + getProfitAfterTax() + "\n" +
				  "==========================================";
	
	return text;
	}
}