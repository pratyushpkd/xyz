package com.bvk.entity;

import java.util.Scanner;

public class MBA extends AbstractStudent {
	private int businessAdmin;
	private int financeMgt;
	private int hrMgt;
	private int exportMgt;
	
	public MBA() {
	}

	@Override
	public void input() {
		super.input();
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter Business Administration: ");
		businessAdmin = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter Finance Management: ");
		financeMgt = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter HR Management: ");
		hrMgt = Integer.parseInt(scInput.nextLine());
		
		System.out.print("Enter Export Management: ");
		exportMgt = Integer.parseInt(scInput.nextLine());		
	}

	@Override
	public void calculateTotal() {
		this.total = this.businessAdmin + this.exportMgt + this.financeMgt + this.hrMgt;
		calculatePercent();
	}

	@Override
	public void calculatePercent() {
		this.percent = this.total/4.0f;
	}

	@Override
	public String toString() {
		return super.toString() + "MBA [businessAdmin=" + businessAdmin + ", financeMgt=" + financeMgt + ", hrMgt=" + hrMgt
				+ ", exportMgt=" + exportMgt + ", toString()=" + "]";
	}
	
	
}