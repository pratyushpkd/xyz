package client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import helper.DBUtil;

public class StudentDAO {
	
	public static void main(String[] args){
		int status[] = new int[3];
		try{
		Connection connStudent = DBUtil.createConnection();

		PreparedStatement pst = connStudent
				.prepareStatement("INSERT INTO stu1 VALUES(?,?,?)");

		pst.setInt(1, 1);
		pst.setString(2, "abc");
		pst.setFloat(3, 85.56f);
		pst.addBatch();
		
		pst.setInt(1, 2);
		pst.setString(2, "xyz");
		pst.setFloat(3, 80.56f);
		pst.addBatch();
		
		pst.setInt(1, 3);
		pst.setString(2, "pqr");
		pst.setFloat(3, 75.56f);
		pst.addBatch();
		
		status = pst.executeBatch();

		System.out.println("Status of above insert statements: ");
		
		for (int i : status) {
			System.out.println(i);
		}
		DBUtil.closeConnection();
		}catch(ClassNotFoundException cnfe){
			cnfe.printStackTrace();
		}catch(SQLException se){
			se.printStackTrace();
		}
		
	}	
}