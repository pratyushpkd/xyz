package client;

import helper.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
		Connection connStudent = DBUtil.createConnection();
		
		PreparedStatement pst = connStudent
				.prepareStatement("INSERT INTO student VALUES(?,?,?)");
		
		//Statement st = connStudent.createStatement();
		
		pst.setInt(1, 1009);
		pst.setString(2, "Amey");
		pst.setFloat(3, 89.90f);
		
		int status = pst.executeUpdate();
		
		if(status == 1){
			System.out.println("Record inserted successfully.");
		}
		DBUtil.closeConnection();
		}catch(ClassNotFoundException cnfe){
			System.out.println(cnfe.getMessage());
		}catch(SQLException se){
			System.out.println(se.getMessage());
		}
	}
}