package client;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import helper.DBUtil;

public class ResultSetDemo {

	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
		Connection connStudent = DBUtil.createConnection();
		ResultSet rsStudent = null;
		
		Statement st = connStudent.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

		rsStudent = st.executeQuery("SELECT empid, name, salary FROM emp1");
		
		/*rsStudent.moveToInsertRow();
		
		rsStudent.updateInt(1, 4803);
		rsStudent.updateString(2, "abc");
		rsStudent.updateFloat(3, 100000);
		
		rsStudent.insertRow();
		rsStudent.first();
		rsStudent.refreshRow();*/
		
		while(rsStudent.next()){
			int r = rsStudent.getInt(1);
			if(r == 4000){
				rsStudent.deleteRow();
/*				rsStudent.moveToCurrentRow();
				
				rsStudent.updateInt(1, 4000);
				rsStudent.updateString(2, "xyz");
				rsStudent.updateFloat(3, 150000);
				rsStudent.updateRow();*/
			}
		}
				//rsStudent.updateRow();
		/*		rsStudent.deleteRow();
			}
		}*/

		if(rsStudent.first()){
			rsStudent.previous();
			while(rsStudent.next()){
				System.out.println("Employee ID: " + rsStudent.getInt(1));
				System.out.println("Name: " + rsStudent.getString(2));
				System.out.println("Salary: " + rsStudent.getFloat(3));
			}
		}
		System.out.println("=======================================================");
		rsStudent.first();
		rsStudent.previous();
		while(rsStudent.next()){
			System.out.println("Employee ID: " + rsStudent.getInt(1));
			System.out.println("Name: " + rsStudent.getString(2));
			System.out.println("Salary: " + rsStudent.getFloat(3));
		}
		DBUtil.closeConnection();
	}
}