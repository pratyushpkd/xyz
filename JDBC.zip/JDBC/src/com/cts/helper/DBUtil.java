package com.cts.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {
	private static Connection connStudent;

	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		ResourceBundle resOracle = ResourceBundle.getBundle("oracle");

		String url = resOracle.getString("url");
		String username = resOracle.getString("username");
		String password = resOracle.getString("password");
		String driver = resOracle.getString("driver");

		Class.forName(driver);

		connStudent = DriverManager.getConnection(url, username, password);

		return connStudent;
	}

	public static void closeConnection() throws SQLException {
		connStudent.close();
	}
}