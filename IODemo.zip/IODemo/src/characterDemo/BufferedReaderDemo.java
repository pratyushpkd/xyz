package characterDemo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReader fr = null;
		BufferedReader br= null;
		String line = null;
		try{
			fr = new FileReader("Buffer.txt");
			br = new BufferedReader(fr,1200);
			
			while((line = br.readLine()) != null){
				System.out.println(line);
			}
		}catch (IOException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}

}