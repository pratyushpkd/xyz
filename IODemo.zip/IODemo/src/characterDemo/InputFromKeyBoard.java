package characterDemo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class InputFromKeyBoard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader br = null;
		
		FileWriter fw = null;
		BufferedWriter bw = null;		
		PrintWriter pw = null;
		
		int number = 0;
		float temperature = 0.0f;
		String input = null;
		
		try{
			br = new BufferedReader(new InputStreamReader(System.in));

			System.out.print("Enter an integer: ");
			input = br.readLine();
			number = Integer.parseInt(input);
			
			System.out.print("Enter a float value: ");
			input = br.readLine();
			temperature = Float.parseFloat(input);
			
			System.out.println(number);
			System.out.println(temperature);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}catch(NumberFormatException nfe){
			System.out.println(nfe.getMessage());
		}finally{
			try{
				if(br != null){
					br.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
		
		try{
			fw = new FileWriter("simplePrim.txt",true);
			bw = new BufferedWriter(fw, 1200);
			pw = new PrintWriter(bw);
			
			pw.println(number);
			pw.println(temperature);
			
		}catch(IOException ie){
			System.out.println("File can't be opened.");
		}finally{
			try{
				if(pw != null){
					pw.close();
				}
				
				if(bw != null){
					bw.close();
				}
			}catch(IOException ie){
				System.out.println("Unable to close the file.");
			}
		}
	}
}