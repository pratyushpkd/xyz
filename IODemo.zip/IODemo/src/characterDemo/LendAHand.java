package characterDemo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class LendAHand {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReader fr = null;
		BufferedReader br= null;
		String line = null;
		StringBuffer buffer = new StringBuffer(20);
		try{
			fr = new FileReader("Buffer.txt");
			br = new BufferedReader(fr);
			
			while((line=br.readLine())!= null){
				buffer.append(line+"\n");
			}
			buffer.reverse();
			System.out.println(buffer);
		}catch (IOException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}finally{
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}
}