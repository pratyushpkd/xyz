package entity;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Student {
	private static final int RECORD_SIZE = 168;//size in bytes.
	private static final int NAME_SIZE = 80;//size in characters.
	private int rollNo;// 4 bytes
	private String name;// 80 characters.
	private float percent;// 4 bytes
	
	public Student() {
	}

	public Student(int rollNo, String name, float percent) {
		this.rollNo = rollNo;
		this.name = name;
		this.percent = percent;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getPercent() {
		return percent;
	}

	public void setPercent(float percent) {
		this.percent = percent;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + ", percent=" + 
				String.format("%.2f", this.percent) + "]";
	}
	
	public void writeToFile(){
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		DataOutputStream dos = null;
		try{
			fos = new FileOutputStream("students.data");
			bos = new BufferedOutputStream(fos, 8192);
			dos = new DataOutputStream(bos);
			
			dos.writeInt(this.rollNo);
			dos.writeUTF(this.name);
			dos.writeFloat(this.percent);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(dos != null){
					dos.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
	
	public void inputFromFile(){
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		try{
			fis = new FileInputStream("students.data");
			bis = new BufferedInputStream(fis, 8192);
			dis = new DataInputStream(bis);
			
			this.rollNo = dis.readInt();
			this.name = dis.readUTF();
			this.percent = dis.readFloat();
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(dis != null){
					dis.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
	
	public void writeToRandomFile(){
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		DataOutputStream dos = null;
		
		char ch = 0;
		int length = this.name.length();
		try{
			fos = new FileOutputStream("studentsrandom.dat", true);
			bos = new BufferedOutputStream(fos, 8192);
			dos = new DataOutputStream(bos);
			
			dos.writeInt(this.rollNo);

			//Writing fixed length string. The maximum name length assumed is 80 bytes.
			
			for(int i = 0 ; i < 80 ; i++){
				ch = 0;
				if(i < length){
					ch = this.name.charAt(i);
				}
				dos.writeChar(ch);
			}
			
			dos.writeFloat(this.percent);
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(dos != null){
					dos.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
	}
	
	public static Student[] readFromRandomFile(){
		Student students[] = null;
		RandomAccessFile rafStudent = null;
		try{
			rafStudent = new RandomAccessFile("studentsrandom.dat", "r");
			long size = rafStudent.length()/RECORD_SIZE;

			students = new Student[(int)size];
			
			for (int i = 0; i < students.length; i++) {
				int rollNo = rafStudent.readInt();
				
				//Reading fixed length string
				
				StringBuilder sbfName = new StringBuilder();
				int j = 0;
				int k = 0;
				
				while(j < NAME_SIZE){
					char ch = rafStudent.readChar();
					j++;
					
					if(ch == 0 && k ==0){
						k = j;
					}
					sbfName.append(ch);
				}
				sbfName.setLength(k-1);
				String name = sbfName.toString();
				
				float percent = rafStudent.readFloat();
				
				students[i] = new Student(rollNo, name, percent);
			}
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}finally{
			try{
				if(rafStudent != null){
					rafStudent.close();
				}
			}catch(IOException ioe){
				System.out.println(ioe.getMessage());
			}
		}
		return students;
	}
}