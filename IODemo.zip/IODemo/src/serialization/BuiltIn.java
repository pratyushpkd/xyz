package serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class BuiltIn {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileOutputStream fos = null;
		FileInputStream fis = null;
		
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		
		int a[] = {1,2,3,4,5};
		String s = new String("abc");
		
		try{
			fos = new FileOutputStream("Objects.ser");
			oos = new ObjectOutputStream(fos);
			
			oos.writeObject(a);//Serialization
			oos.writeObject(s);//Serialization
		}catch(IOException ie){
			System.out.println("Problem in IO.");
		}finally{
			try {
				oos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		try{
			fis = new FileInputStream("Objects.ser");
			ois = new ObjectInputStream(fis);
			
			try {
				a = (int[])ois.readObject();//De-serialization
				s = (String)ois.readObject();//De-serialization
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}catch(IOException ie){
			System.out.println("Problem in IO.");
		}finally{
			try {
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("Data read from file is as follows:");
		
		for(int data : a){
			System.out.print(data + "\t");
		}
		System.out.println();
		
		System.out.println(s);
	}
}