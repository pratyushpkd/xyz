package serialization;
import java.io.Serializable;
import java.util.Scanner;


public class Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6585061706640755345L;

	/**
	 * 
	 */
	

	private static int totalSalary;//Not serialized.
	
	private int id;//Serialized
	private String name;//Serialized
	private transient int age;//Not Serialized.
	private int salary;//Serialized
	
	public Employee() {
		super();
	}

	public Employee(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	public static int getTotalSalary() {
		return totalSalary;
	}

	public static void setTotalSalary(int totalSalary) {
		Employee.totalSalary = totalSalary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	public void input(){
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Employee ID: ");
		id = s.nextInt();
		
		System.out.println("Enter Employee name: ");
		name = s.next();
		
		System.out.println("Enter Employee Salary: ");
		salary = s.nextInt();
		
		totalSalary += salary;
		s.close();
	}
	
	public String toString(){
		return "ID: " + id + "\n"+
		"Name: " + name + "\n"+
		"Salary: "+salary;
	}
}