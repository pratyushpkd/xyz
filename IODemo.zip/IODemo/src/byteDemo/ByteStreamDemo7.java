package byteDemo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		int value = 0;
		
		
		try(FileInputStream fis = new FileInputStream("e:\\abc.txt");
			FileOutputStream fos = new FileOutputStream("e:\\target4.txt");
				
   			BufferedInputStream	bis = new BufferedInputStream(fis, 1200);
			BufferedOutputStream bos = new BufferedOutputStream(fos, 1200);){
			
			
			//fis.read(contents);
			value = bis.read();
			while(value != -1){
				bos.write(value);
				value=bis.read();
			}
			//bos.flush();
		}catch(IOException fnfe){
			System.out.println("File is not found.");
		}
		System.out.println("Done with copying file.");
	}
}