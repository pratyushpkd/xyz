package byteDemo;

import entity.Student;

public class ClientStudent {

	public static void main(String[] args) {
		Student student = new Student(1, "bvk", 100);
		
		student.writeToFile();
		
		student.inputFromFile();
		
		System.out.println(student);
	}
}